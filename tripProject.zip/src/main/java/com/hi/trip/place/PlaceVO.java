package com.hi.trip.place;

public class PlaceVO {

}
