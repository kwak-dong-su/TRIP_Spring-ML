package com.hi.trip.itinerary;

public class ItineraryVO {

}
