package com.hi.trip.itinerary;

import org.springframework.stereotype.Controller;

@Controller
public class ItineraryController {

}
