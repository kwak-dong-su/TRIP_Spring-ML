package com.hi.trip.surveyResult;

public class SurveyResultDAO {

}
