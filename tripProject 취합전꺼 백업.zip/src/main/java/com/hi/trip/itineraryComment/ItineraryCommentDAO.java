package com.hi.trip.itineraryComment;

public class ItineraryCommentDAO {

}
