package com.hi.trip.statistics;

public class StatisticsVO {

}
