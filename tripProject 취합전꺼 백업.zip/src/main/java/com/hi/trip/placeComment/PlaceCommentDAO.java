package com.hi.trip.placeComment;

public class PlaceCommentDAO {

}
